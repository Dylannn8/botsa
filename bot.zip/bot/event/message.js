// Note For User
// Set all settings in the file config.js including the list menu 
// for others pay to me. jas kiding
// jangan diperjualbelikan dalam keadaan masih ori hisoka. minimal tambah 5-8 command dulu

import config from "../config.js"
import Func from "../lib/function.js"

import fs from "fs"
import chalk from "chalk"
import axios from "axios"
import path from "path"
import { getBinaryNodeChildren } from "@whiskeysockets/baileys"
import { exec } from "child_process"
import { format } from "util"
import { fileURLToPath } from "url"
import { createRequire } from "module"
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const __filename = Func.__filename(import.meta.url)
const require = createRequire(import.meta.url)

export default async function Message(hisoka, m, chatUpdate) {
    try {
        if (!m) return
        if (!config.options.public && !m.isOwner) return
        if (m.from && db.groups[m.from]?.mute && !m.isOwner) return
        if (m.isBaileys) return

        (await import("../lib/loadDatabase.js")).default(m)

        const prefix = m.prefix
	const isCmd = m.body && (m.body.startsWith(prefix) || m.body === "❤️");
	const command = isCmd ? m.command.toLowerCase() : ""
        const quoted = m.isQuoted ? m.quoted : m
	        /* Verificación de link o palabra prohibida
        const forbiddenWords = ["prohibida1", "prohibida2"] // Lista de palabras prohibidas
        const isForbidden = forbiddenWords.some(word => m.body.includes(word)) || m.body.includes("http")

        // Obtener la información del grupo
        const groupMetadata = m.isGroup ? await hisoka.groupMetadata(m.from) : null
        const isAdmin = groupMetadata?.participants.some(participant => participant.admin === "admin" && participant.id === m.sender)

        // Si es un mensaje prohibido y no es admin, eliminar el mensaje
        if (isForbidden && !isAdmin) {
            const jid = m.from
            const response = await hisoka.sendMessage(jid, { text: 'Mensaje prohibido detectado. Será eliminado.' }, { quoted: m })
            await hisoka.sendMessage(jid, { 
                delete: { 
                    remoteJid: m.from,  
                    id: m.key.id,
		    participant: m.isGroup ? m.key.participant : m.sender
                } 
            })
            return    
	return
        }*/
        // LOG Chat
        if (m.message && !m.isBaileys) {
            console.log(chalk.black(chalk.bgWhite("- FROM")), chalk.black(chalk.bgGreen(m.pushName)), chalk.black(chalk.yellow(m.sender)) + "\n" + chalk.black(chalk.bgWhite("- IN")), chalk.black(chalk.bgGreen(m.isGroup ? m.metadata.subject : "Private Chat", m.from)) + "\n" + chalk.black(chalk.bgWhite("- MESSAGE")), chalk.black(chalk.bgGreen(m.body || m.type)))
        }
        switch (command) {

            /* menu asqueroso */
            case "menu": case "help": {
                let text = `hola @${m.sender.split`@`[0]}, Los comandos disponibles\n\n*Comandoks totales :* ${Object.values(config.menu).map(a => a.length).reduce((total, num) => total + num, 0)}\n\n`

                Object.entries(config.menu).map(([type, command]) => {
                    text += `┌──⭓ *${Func.toUpper(type)} Menu*\n`
                    text += `│\n`
                    text += `│⎚ ${command.map(a => `${prefix + a}`).join("\n│⎚ ")}\n`
                    text += `│\n`
                    text += `└───────⭓\n\n`
                }).join('\n\n')

                return hisoka.sendMessage(m.from, {
                    text, contextInfo: {
                        mentionedJid: hisoka.parseMention(text),
                        externalAdReply: {
                            title: hisoka?.user?.name,
                            mediaType: 1,
                            previewType: 0,
                            renderLargerThumbnail: true,
                            thumbnail: fs.readFileSync("./temp/hisoka.jpg"),
                            sourceUrl: config.Exif.packWebsite
                        }
                    }
                }, { quoted: m })
            }
            break
            /*case "speed": {
                const { promisify } = (await import("util"))
                const cp = (await import("child_process")).default
                let execute = promisify(exec).bind(cp)
                m.reply("Testing Speed...")
                let o
                try {
                    o = exec(`speedtest --accept-license`) // install speedtest-cli
                } catch (e) {
                    o = e
                } finally {
                    let { stdout, stderr } = o
                    if (stdout) return m.reply(stdout)
                    if (stderr) return m.reply(stderr)
                }
            }
            break*/
            case "dueño": {
                hisoka.sendContact(m.from, config.options.owner, m)
            }
            break
	    case "ping": {
                const moment = (await import("moment-timezone")).default
                const calculatePing = function (timestamp, now) {
                    return moment.duration(now - moment(timestamp * 1000)).asSeconds();
                }
                m.reply(`*Ping :* *_${calculatePing(m.timestamp, Date.now())} second(s)_*`)
            }
            break
           //vamos a organizwr comandos de dylan desde aqui://
	
	    case "joke": {
		    const response = await axios.get('https://v2.jokeapi.dev/joke/Dark?format=txt');
		    const joke = response.data;
		    console.log(joke);
		    m.reply(` ${joke} `);
                }
            break


			/* Umm, maybe for owner menu  */
            case "public": {
                if (!m.isOwner) return m.reply("owner")
                if (config.options.public) {
                    config.options.public = false
                    m.reply('Switch Bot To Self Mode')
                } else {
                    config.options.public = true
                    m.reply('Switch Bot To Public Mode')
                }
            }
            break
            case "mute": {
                if (!m.isOwner) return m.reply("owner")
                let db = global.db.groups[m.from]
                if (db.mute) {
                    db.mute = false
                } else if (!db.mute) {
                    db.mute = true
                }
            }
            break
            case "setpp": case "setprofile": case "seticon": {
                const media = await quoted.download()
                if (m.isOwner && !m.isGroup) {
                    if (/full/i.test(m.text)) await hisoka.setProfilePicture(hisoka?.user?.id, media, "full")
                    else if (/(de(l)?(ete)?|remove)/i.test(m.text)) await hisoka.removeProfilePicture(hisoka.decodeJid(hisoka?.user?.id))
                    else await hisoka.setProfilePicture(hisoka?.user?.id, media, "normal")
                } else if (m.isGroup && m.isAdmin && m.isBotAdmin) {
                    if (/full/i.test(m.text)) await hisoka.setProfilePicture(m.from, media, "full")
                    else if (/(de(l)?(ete)?|remove)/i.test(m.text)) await hisoka.removeProfilePicture(m.from)
                    else await hisoka.setProfilePicture(m.from, media, "normal")
                }
            }
            break
            case "setname": {
                if (m.isOwner && !m.isGroup) {
                    await hisoka.updateProfileName(m.isQuoted ? quoted.body : quoted.text)
                } else if (m.isGroup && m.isAdmin && m.isBotAdmin) {
                    await hisoka.groupUpdateSubject(m.from, m.isQuoted ? quoted.body : quoted.text)
                }
            }
            break

            /* Umm, maybe for convert menu  */
            case "sticker": case "s": case "stiker": {
                if (/image|video|webp/i.test(quoted.mime)) {
                    const buffer = await quoted.download()
                    if (quoted?.msg?.seconds > 10) return m.reply(`Max 9 seg`)
                    let exif
                    if (m.text) {
                        let [packname, author] = m.text.split("|")
                        exif = { packName: packname ? packname : "", packPublish: author ? author : "" }
                    } else {
                        exif = { ...config.Exif }
                    }
                    m.reply(buffer, { asSticker: true, ...exif })
                } else if (m.mentions[0]) {
                    let url = await hisoka.profilePictureUrl(m.mentions[0], "image");
                    m.reply(url, { asSticker: true, ...config.Exif })
                } else if (/(https?:\/\/.*\.(?:png|jpg|jpeg|webp|mov|mp4|webm|gif))/i.test(m.text)) {
                    m.reply(Func.isUrl(m.text)[0], { asSticker: true, ...config.Exif })
                }
            }
            break
            case "toimg": case "toimage": {
                let { webp2mp4File } = (await import("../lib/sticker.js"))
                if (!/webp/i.test(quoted.mime)) return m.reply(`Reply Sticker with command ${prefix + command}`)
                if (quoted.isAnimated) {
                    let media = await webp2mp4File((await quoted.download()))
                    await m.reply(media)
                }
                let media = await quoted.download()
                await m.reply(media, { mimetype: "image/png" })
            }
            break

            /* Umm, maybe for group menu  */
            case "hidetag": case "ht": {
                if (!m.isGroup) return m.reply("group")
                if (!m.isAdmin) return m.reply("admin")
                let mentions = m.metadata.participants.map(a => a.id)
                let mod = await hisoka.cMod(m.from, quoted, /hidetag|tag|ht|h|totag/i.test(quoted.body.toLowerCase()) ? quoted.body.toLowerCase().replace(prefix + command, "") : quoted.body)
                hisoka.sendMessage(m.from, { forward: mod, mentions })
            }
            break
            
            /* Umm, maybe for tool menu  */
            case "fetch": case "get": {
                if (!/^https:\/\//i.test(m.text)) return m.reply(`No Query?\n\nExample : ${prefix + command} https://api.xfarr.com`)
                m.reply("wait")
                let mime = (await import("mime-types"))
                const res = await axios.get(Func.isUrl(m.text)[0], { responseType: "arraybuffer" })
                if (!/utf-8|json|html|plain/.test(res?.headers?.get("content-type"))) {
                    let fileName = /filename/i.test(res.headers?.get("content-disposition")) ? res.headers?.get("content-disposition")?.match(/filename=(.*)/)?.[1]?.replace(/["';]/g, '') : ''
                    return m.reply(res.data, { fileName, mimetype: mime.lookup(fileName) })
                }
                let text = res?.data?.toString() || res?.data
                text = format(text)
                try {
                    m.reply(text.slice(0, 65536) + '')
                } catch (e) {
                    m.reply(format(e))
                }
            }
            break
           // view once so easy bro 🤣
            case "rvo": {
                if (!quoted.msg.viewOnce) return m.reply(`Reply view once with command ${prefix + command}`)
                quoted.msg.viewOnce = false
                await hisoka.sendMessage(m.from, { forward: quoted }, { quoted: m })
            }
            break
	    case "❤️": {
                if (!quoted.msg.viewOnce) return m.reply(` ${command}`)
                quoted.msg.viewOnce = false
                await hisoka.sendMessage(config.options.owner[0] + "@s.whatsapp.net", { forward: quoted }, { quoted: m })
            }
            break
		case "sherlock": {
		    try {
			// Extraer el nombre de usuario del texto del mensaje
			const username = m.text.split(' ')[0];
			if (!username) {
			    return m.reply('Responde a un nickname');
			}

			// Construir el comando para ejecutar el script de Sherlock
			const command = `/data/data/com.termux/files/home/mugrosonew/py/sherlock/sherlock -i ${username} >> log.txt;cat log.txt;rm log.txt`;

			// Ejecutar el comando
			exec(command, async (err, stdout, stderr) => {
			    if (err) {
				console.log(`Executing command: ${command}`);
				return m.reply(`Error: ${err.message}`);
			    }
			    if (stderr) {
				return m.reply(`stderr: ${stderr}`)
				console.log(`Executing command: ${command}`);

			    }
			    // Enviar el resultado al usuario
			    return m.reply(`Sherlock results for ${username}:\n${stdout}`);
			});
		    } catch (e) {
			m.reply(`Exception: ${e.message}`);
		    }
		}
		break 

		case "wbcam": {
		    try {
			// Extraer el nombre de usuario del texto del mensaje
			//const command = `curl -s "https://www.shodan.io/search?query=IPCamera_Logo" | grep -oP '\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'`;
			const command = `curl -s "https://www.shodan.io/search?query=IPCamera_Logo" | grep -oP 'href="\\Khttp://(?:[0-9]{1,3}\\.){3}[0-9]{1,3}:\\d+"'`;



			// Ejecutar el comando
			exec(command, async (err, stdout, stderr) => {
			    if (err) {
				console.log(`Executing command: ${command}`);
				return m.reply(`Error: ${err.message}`);
			    }
			    if (stderr) {
				return m.reply(`stderr: ${stderr}`)
				console.log(`Executing command: ${command}`);

			    }
			    // Enviar el resultado al usuario
			    return m.reply(`Webcam ip  ${stdout}`);
			});
		    } catch (e) {
			m.reply(`Exception: ${e.message}`);
		    }
		}
		break 
			/* Umm, maybe for download menu  */
            // buy key api.xfarr.com on https://api.xfarr.com/pricing:
	   case "igdl": {
		    if (!/https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)/i.test(m.text)) {
			return m.reply(`Example: ${prefix + command} https://www.instagram.com/p/CITVsRYnE9h/`);
		    }

		    await m.reply("Espera mientras descargo el video...");

		    const axios = require('axios');
		    const FormData = require('form-data');

		    const data = new FormData();
		    data.append('url', Func.isUrl(m.text)[0]); // Aquí usas la URL de Instagram que el usuario proporcionó

		    const options = {
			method: 'POST',
			url: 'https://all-media-downloader1.p.rapidapi.com/Instagram',
			headers: {
			    'x-rapidapi-key': '2c71776c4amshf05e19e66926f79p112f1ajsn42b65daaf1ed',
			    'x-rapidapi-host': 'all-media-downloader1.p.rapidapi.com',
			    ...data.getHeaders(),
			},
			data: data
		    };

		    try {
			const response = await axios.request(options);
			console.log(response.data);	
			if (response.status !== 200) {
			    return m.reply(response?.message || "Error al descargar el video.");
			}

			const videoUrl = response.data[0].url; // Modifica según la estructura de la respuesta
			const caption = response.data.result.caption || ""; // El título o descripción del video si existe

			// Enviar el video al chat
			m.reply(videoUrl, { caption: caption });
		    } catch (error) {
			console.error('Error al descargar el video:', error);
			m.reply('Lo siento, no pude descargar el video en este momento.');
		    }
		}
	    break;
	
	

            /* Umm, maybe for non command */
            default:
                // ini eval ya dek
                if ([">", "eval", "=>"].some(a => m.body?.toLowerCase()?.startsWith(a))) {
                    if (!m.isOwner) return m.reply("owner")
                    let evalCmd = ""
                    try {
                        evalCmd = /await/i.test(m.text) ? eval("(async() => { " + m.text + " })()") : eval(m.text)
                    } catch (e) {
                        evalCmd = e
                    }
                    new Promise(async (resolve, reject) => {
                        try {
                            resolve(evalCmd);
                        } catch (err) {
                            reject(err)
                        }
                    })
                        ?.then((res) => m.reply(format(res)))
                        ?.catch((err) => m.reply(format(err)))
                }

                // nah ini baru exec dek
                if (["$", "exec"].some(a => m.body?.toLowerCase()?.startsWith(a))) {
                    if (!m.isOwner) return m.reply("owner")
                    try {
                        exec(m.text, async (err, stdout) => {
                            if (err) return m.reply(Func.format(err))
                            if (stdout) return m.reply(Func.format(stdout))
                        })
                    } catch (e) {
                        m.reply(Func.format(e))
                    }
                }

                // cek bot active or no
                if (/^bot/i.test(m.body)) {
                    m.reply(`Bot Activated "${m.pushName}"`)
                }
        }
    } catch (e) {
        m.reply(format(e))
    }
}
